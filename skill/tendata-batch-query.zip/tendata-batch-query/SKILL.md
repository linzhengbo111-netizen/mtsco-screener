---
name: tendata-batch-query
description: Batch customer enrichment via TenData. Supports text company lists and Excel file uploads. Calls a remote execution engine API.
version: 0.2.1
---

# TenData Batch Query

## What this skill does

Accepts a list of company names (text or Excel), sends them to a remote execution engine that scrapes TenData for enrichment data, then returns structured results.

## Configuration

**BASE_URL**: `https://alike-quench-entwine.ngrok-free.dev`

> This URL is stable and does not change.

## Input Detection

| User action | Input type |
|-------------|-----------|
| Types multiple company names in chat (one per line) | Text list |
| Uploads `.xlsx` / `.xls` file | Excel upload |

## Text List Flow

### Step 1: Parse

Convert user input to a JSON array:

```json
[
  {"customer_name": "公司A", "country_region": "US", "website": "example.com"},
  {"customer_name": "公司B", "country_region": "", "website": ""}
]
```

Rules:
- `customer_name` is required. Skip blank lines.
- `country_region` and `website` are optional — extract from the line if present (e.g., "Google US https://google.com")
- Each line = one company

### Step 2: Create Batch

```
POST {BASE_URL}/api/batch/create
Content-Type: application/json
ngrok-skip-browser-warning: true

{
  "customers": [...parsed JSON...],
  "source": "openclaw"
}
```

Save the returned `batch_id`.

### Step 3: Poll Status (aggressive-then-relaxed)

Poll immediately after create, then follow this schedule:

| Phase | Interval | Duration |
|-------|----------|-------------|
| Phase 1 | every **5 seconds** | 0–30s (~6 attempts) |
| Phase 2 | every **10 seconds** | 30–120s (~9 attempts) |
| Phase 3 | every **15 seconds** | >120s, max 30 total attempts |

```
GET {BASE_URL}/api/batch/status?batch_id={batch_id}
ngrok-skip-browser-warning: true
```

**Stop condition:** As soon as `status` is `completed` or `partial_failed`, **immediately** proceed to Step 4 (Get Result). Do NOT wait for the next scheduled poll.

Maximum total attempts: 30. If still running after 30 polls, tell user: "任务仍在执行中，请稍后手动查询".

### Step 4: Get Result

```
GET {BASE_URL}/api/batch/result?batch_id={batch_id}
ngrok-skip-browser-warning: true
```

If it times out, retry once.

### Step 5: Reply (Default Data Summary)

Every customer in the batch result MUST display a **data summary card**. Do NOT return an empty or generic "query completed" message.

For each customer, show the following fields (skip if empty/unknown):

| Field | Description |
|-------|------------|
| `matched_company_name` | 匹配到的腾道企业名称 |
| `match_status` | 匹配状态：matched / no_result / ambiguous |
| `match_confidence` | 匹配置信度 (0-100) |
| `location` | 企业地址/位置 |
| `website` | 企业官网 |
| `phone` | 联系电话 |
| `linkedin` | LinkedIn 链接 |
| `latest_import_date` | 最新进口日期 |
| `import_active_status` | 进口活跃状态 |
| `top_products` | Top 产品关键词（从 `top_products_json` 解析） |
| `top_suppliers` | Top 供应商（从 `top_suppliers_json` 解析，默认展示前 3 条） |

If the customer has import record data available (i.e., `top_suppliers_json` or `target_hs_amount_json` is populated), also show:

**最近 3 条进口记录**（从 `top_suppliers_json` 取前 3 条）：

| supplier_name | trade_count | usd_amount |
|--------------|-------------|-----------|
| ... | ... | ... |

### Step 5b: Expanded Detail Mode

Enter detail mode ONLY when the user explicitly asks to expand:

**Trigger phrases:**
- "展开明细" / "给我最近10条进口记录" / "显示全部进口记录"
- "进口记录明细" / "看下进口明细" / "进口供应商明细"
- "import records" / "import details" / "supplier details" / "show me the HS breakdown"

When triggered, for each customer with available data:

1. **Top Suppliers** (from `top_suppliers_json`): show ALL entries (not limited to 3)
   - `supplier_name`, `trade_count`, `usd_amount`

2. **HS Code Breakdown** (from `target_hs_amount_json`):
   - `hs_code`, `usd_amount`

3. **Latest Import Date** (from `latest_import_date`)

**No data fallback:** If `top_suppliers_json` and `target_hs_amount_json` are both empty for a customer, reply: "当前未提取到可展示的进口记录明细"。

**Limitation notice:** If the user asks for per-record import data with exact dates and product names (逐条进口记录，含每笔日期、产品名称), inform them: "当前仅支持展示供应商汇总和 HS 编码汇总数据，逐条进口明细（含日期、产品名称）需要后续升级抓取能力。"

---

### Step 5c: Priority Scoring (auto-applied after every batch result)

After formatting the data summary (Step 5) and before returning the result, run a **priority scoring** pass on each customer. Use the rules defined in `priority_rules_v1.md`.

For each customer, append these fields to the output:

| Field | Type | Description |
|-------|------|-------------|
| `priority_score` | int | Numeric score (base 50, +/- adjustments) |
| `priority_level` | string | `high` / `medium` / `low` / `skip` |
| `priority_reason` | string | One-line summary of scoring rationale (Chinese) |
| `recommended_action` | string | `主动开发` / `保持跟进` / `保持关注` / `暂不跟进` |
| `recommended_entry_point` | string | Suggested entry point based on supplier/HS data |
| `recommended_script_direction` | string | Communication direction / talking points |

**Do not ask the user** — this scoring is automatic and silent. Just append it to each customer card.

#### Example output per customer:

```
【优先级评估】
  优先级得分：78
  优先级等级：高
  评估原因：近6月有进口记录，采购金额>$100万，联系方式齐全
  推荐动作：主动开发
  推荐切入点：从 HS 编码 123456 产品线切入，该公司现有供应商为 ABC Electronics（年采购额 $1,250,000）
  沟通方向：强调替代方案，指出当前供应商 ABC Electronics 的采购额 $1,250,000，我们有更优价格和交期
```

---

## Excel Upload Flow

### Step 1: Read Excel

Use the xlsx skill to read the uploaded file's first sheet.

### Step 2: Map Headers

#### Priority 1: Standard template headers

If columns exactly match: `company_name`, `country`, `website` → direct mapping.

#### Priority 2: Alias recognition (case-insensitive, trimmed)

| Target field | Accepted aliases |
|-------------|-----------------|
| **customer_name** | 公司名, 客户名称, 企业名称, 公司名称, 公司, 客户, Company Name, Customer Name, companyname, customername |
| **country_region** | 国家, 国家地区, 地区, Country, Region, countryregion, 国家/地区, 国别 |
| **website** | 官网, 网站, 网址, Website, URL, 公司网址, companywebsite |

Matching order:
1. Exact match (case-insensitive, trimmed)
2. Contains match (e.g., "客户名称(中文)" matches "客户名称")

### Step 3: Ambiguous headers → ask user

DO NOT proceed automatically if:
- No column resembles company name → ask: "未识别到公司名列，请确认哪一列是公司名称"
- Two columns both look like company name → ask: "发现两列都可能公司名，请确认用哪一列"
- No header row detected → ask: "请确认第一行是否为表头，或提供列号对应关系"

Wait for user reply before continuing.

### Step 4: Build customers array

Read row by row. Skip rows where `customer_name` is empty.

```json
[
  {"customer_name": "公司名", "country_region": "国家（如有）", "website": "官网（如有）"}
]
```

### Step 5: Create / Poll / Result / Priority

Same as Text List Flow steps 2-5c (includes data summary, detail mode, and automatic priority scoring).

---

## Important Rules

### Real-time Query vs Cached Results

1. **Default: always create a new batch.** Whenever the user submits company names (text or Excel), you MUST call `create` → `status` → `result` in full. Never return cached or historical results from a previous conversation turn.
2. **Never reuse a previous `batch_id`** unless the user explicitly says one of:
   - "基于上一次结果继续"
   - "不要重新查"
   - "看刚才的结果"
   - "use the last result"
   - Other unambiguous phrasing that means "don't re-query"
3. If the user asks for a result you already have from earlier in this conversation, still re-query by default. Only skip if they explicitly tell you not to.

### Query Report (required in every real-time query response)

Every real-time query response MUST end with a query report block:

```
--- Query Report ---
- batch_id: BATCH-xxx
- Called create: Yes
- Polling status: Yes (N polls, ~X min)
- Result batch_id: BATCH-xxx
- Query time: YYYY-MM-DD HH:MM:SS (UTC+8)
-------------------
```

This proves the query was actually executed and not pulled from cache.

### Other Rules

4. **Always include** `ngrok-skip-browser-warning: true` header in every request
5. **Retry `result` once** if it times out, but don't poll aggressively
6. **`source` must be `"openclaw"`**
7. If polling 30 times without completion → tell user: "任务仍在执行中，请稍后手动查询"
8. If batch creation fails → tell the user why

## Excel Template

For users who need a template, the standard format is:

| company_name | country | website |
|-------------|---------|---------|
| 上海某某公司 | CN | https://example.com |

The skill also accepts user's own Excel files — it will auto-detect headers.
